<?php 

$lang['signin'] = 'Sign In';
$lang['register'] = 'Register';
$lang['login'] = 'Login';
$lang['change'] = 'Change';
$lang['send_me_link'] = 'Send me new password';
$lang['reset_password'] = 'Reset password';
$lang['create'] = 'Create';
$lang['manage'] = 'Manage';
$lang['deactivate'] = 'Deactivate';
$lang['redirect'] = 'Redirect Now';
$lang['check_domain'] = 'Check Domain';
$lang['configure'] = 'Configure';
$lang['subdomain'] = 'Subdomain';
$lang['custom_domain'] = 'Custom Domain';
$lang['check_availibilty'] = 'Check Availibilty';
$lang['create_account'] = 'Create Account';
$lang['view_accounts'] = 'View Accounts';
$lang['request'] = 'Request';
$lang['search'] = 'Search';
$lang['resend_email'] = 'Resend Email';
$lang['logout'] = 'Logout';
$lang['control_panel'] = 'Control Panel';
$lang['file_manager'] = 'File Manager';
$lang['reactivate'] = 'Reactivate';
$lang['settings'] = 'Settings';
$lang['open_ticket'] = 'Open Ticket';
$lang['delete'] = 'Delete';
$lang['cancel'] = 'Cancel';
$lang['here'] = 'here';
$lang['close_ticket'] = 'Close Ticket';
$lang['add_reply'] = 'Add Reply';

?>
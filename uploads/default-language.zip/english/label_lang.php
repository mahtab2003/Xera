<?php 

$lang['email_address'] = 'Email Address';
$lang['username'] = 'Username';
$lang['password'] = 'Password';
$lang['old_password'] = 'Old Password';
$lang['new_password'] = 'New Password';
$lang['confirm_password'] = 'Confirm Password';
$lang['your_name'] = 'Your Name';
$lang['recaptcha'] = 'Recaptcha';
$lang['language'] = 'Language';
$lang['subject'] = 'Subject';
$lang['content'] = 'Content';
$lang['domain'] = 'Domain';
$lang['theme'] = 'Theme';
$lang['label'] = 'Label';
$lang['csr_code'] = 'CSR Code';
$lang['crt_code'] = 'CRT Code';
$lang['ca_code'] = 'CA Code';
$lang['reason'] = 'Reason';
$lang['domain_name'] = 'Domain Name';
$lang['account_label'] = 'Account Label';
$lang['ok'] = 'OK';
$lang['error'] = 'Error';
$lang['redirecting'] = 'Redirecting';
$lang['or'] = 'or';
$lang['show_hide'] = 'Show/Hide';
$lang['record_name'] = 'Record Name';
$lang['record Content'] = 'Record Content';

?>
<?php 

$lang['id'] = 'ID';
$lang['username'] = 'Username';
$lang['label'] = 'Label';
$lang['status'] = 'Status';
$lang['action'] = 'Action';
$lang['domain'] = 'Domain';
$lang['method'] = 'Method';
$lang['subject'] = 'Subject';
$lang['date'] = 'Date';
$lang['pending'] = 'Pending';
$lang['active'] = 'Active';
$lang['deactivated'] = 'Deactivated';
$lang['reactivated'] = 'Reactivated';
$lang['suspended'] = 'Suspended';
$lang['deactivating'] = 'Deactivating';
$lang['reactivating'] = 'Reactivating';
$lang['open'] = 'Open';
$lang['customer'] = 'Customer';
$lang['support'] = 'Support';
$lang['closed'] = 'Closed';
$lang['processing'] = 'Processing';
$lang['cancelled'] = 'Cancelled';
$lang['password'] = 'Password';
$lang['port'] = 'Port';
$lang['hostname'] = 'Hostname';
$lang['main_domain'] = 'Main Domain';
$lang['cpanel_domain'] = 'cPanel Domain';
$lang['website_ip'] = 'Website IP';
$lang['created_on'] = 'Created On';
$lang['database_name'] = 'Database Name';
$lang['start_date'] = 'Start Date';
$lang['end_date'] = 'End Date';
$lang['open_at'] = 'Open at';
$lang['open_by'] = 'Open by';
$lang['last_reply'] = 'Last reply';

?>